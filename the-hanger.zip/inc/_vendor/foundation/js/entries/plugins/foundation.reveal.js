import { Foundation } from './foundation.core';

import { Reveal } from '../../foundation.reveal';
Foundation.plugin(Reveal, 'Reveal');
