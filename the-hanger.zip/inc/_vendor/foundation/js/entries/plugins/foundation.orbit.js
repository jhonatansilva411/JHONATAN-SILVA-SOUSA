import { Foundation } from './foundation.core';

import { Orbit } from '../../foundation.orbit';
Foundation.plugin(Orbit, 'Orbit');

