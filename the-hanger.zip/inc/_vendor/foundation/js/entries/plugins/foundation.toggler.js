import { Foundation } from './foundation.core';

import { Toggler } from '../../foundation.toggler';
Foundation.plugin(Toggler, 'Toggler');

