import { Foundation } from './foundation.core';
import $ from 'jquery';

import { Triggers } from '../../foundation.util.triggers';
Triggers.init($, Foundation);
